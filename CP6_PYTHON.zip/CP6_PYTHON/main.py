from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, Integer, String, Float, Date
from sqlalchemy.orm import sessionmaker, declarative_base
from datetime import date
from typing import List


DATABASE_URL = "sqlite:///./eventos.db"


engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


Base = declarative_base()


class EventoDB(Base):
    __tablename__ = "eventos"
    id = Column(Integer, primary_key=True, index=True)
    nome = Column(String, nullable=False)
    descricao = Column(String, nullable=False)
    preco = Column(Float, nullable=False)
    data = Column(Date, nullable=False)
    localizacao = Column(String, nullable=False)


Base.metadata.create_all(bind=engine)


class Evento(BaseModel):
    nome: str
    descricao: str
    preco: float
    data: date
    localizacao: str

class EventoOut(Evento):
    id: int


app = FastAPI()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.post("/eventos/", response_model=EventoOut)
def criar_evento(evento: Evento, db: SessionLocal = next(get_db())):
    novo_evento = EventoDB(**evento.dict())
    db.add(novo_evento)
    db.commit()
    db.refresh(novo_evento)
    return novo_evento


@app.get("/eventos/{evento_id}", response_model=EventoOut)
def obter_evento_por_id(evento_id: int, db: SessionLocal = next(get_db())):
    evento = db.query(EventoDB).filter(EventoDB.id == evento_id).first()
    if not evento:
        raise HTTPException(status_code=404, detail="Evento não encontrado")
    return evento


@app.get("/eventos/", response_model=List[EventoOut])
def buscar_eventos_por_nome(nome: str = Query(None), db: SessionLocal = next(get_db())):
    eventos = db.query(EventoDB).filter(EventoDB.nome.contains(nome)).all()
    return eventos


@app.put("/eventos/{evento_id}", response_model=EventoOut)
def atualizar_evento(evento_id: int, evento: Evento, db: SessionLocal = next(get_db())):
    evento_existente = db.query(EventoDB).filter(EventoDB.id == evento_id).first()
    if not evento_existente:
        raise HTTPException(status_code=404, detail="Evento não encontrado")
    for key, value in evento.dict().items():
        setattr(evento_existente, key, value)
    db.commit()
    db.refresh(evento_existente)
    return evento_existente


@app.delete("/eventos/{evento_id}")
def deletar_evento(evento_id: int, db: SessionLocal = next(get_db())):
    evento = db.query(EventoDB).filter(EventoDB.id == evento_id).first()
    if not evento:
        raise HTTPException(status_code=404, detail="Evento não encontrado")
    db.delete(evento)
    db.commit()
    return {"message": "Evento deletado com sucesso"}
